import React from 'react'
import { GooglePlusOutlined } from '@ant-design/icons';

const Footer = () => {
    return (
        <div>
            <h2>This is the Footer</h2>
            <div><GooglePlusOutlined /> specsexample@gmail.com</div>
        </div>
      );
};

export default Footer;
