import React from 'react'

const Header = () => {
    return (
        <div>
            <h1>This is the header</h1>
        </div>
      );
};

export default Header;

