import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <p>Main part</p>
    </div>
  );
}

export default App;
